## Tulinen Lähi-idän Nakkikastike (4–5 hengelle)

Nakkikastike lähi-itäläisellä tai israelilaisella vivahteella on aivan loistava ja luova idea! Tästä yhdistelmästä tulee vähän kuin paikallinen katuruoka modernilla otteella.

Lähi-idässä (erityisesti Israelissa) rakastetaan tulisia maustetahnoja kuten harissaa tai zhugia, ja tomaattipohjaiset, mausteiset makkararuoat (kuten merguez-makkarat tomaattikastikkeessa) ovat suosittuja. Tehdään siis perinteisestä ruskeasta kastikkeesta tulinen, tomaattinen ja itämaisesti maustettu versio, joka sopii täydellisesti perunoiden, kurkkusalaatin ja sen leipomasi laffa-leivän kaveriksi!

### Ainekset:

  * Nakkeja: 400–500 g (paloiteltuna)

  * Rypsiöljyä: 3 rkl (paistamiseen)

  * Vehnäjauhoja: 3 rkl (kastikkeen suurustamiseen)

  * Tomaattipyrettä: 1 pieni tölkki (n. 70 g) tai 3–4 rkl

  * Vettä: n. 5–6 dl

  * Lihaliemikuutio

## Lähi-idän maustepaletti (sekoita nämä tulisuuden saamiseksi):

  * Chilijauhetta tai cayenne-pippuria: 0,5–2 tl (riippuen siitä, kuinka tulisen haluat!)
  
  * Juustokuminaa (jeeraa): 1 tl (tämä antaa sen aidon Lähi-idän tuoksun ja maun)

  * Paprikajauhetta: 1 tl

  * Mustapippuria: myllystä muutama pyöräytys

  (Jos kaapista löytyy valkosipulia tai sipulia, pilko ihmeessä sekaan!)

### Teet näin:

 1. Ruskista nakit ja tee pohja: Kuumenna öljy pannulla tai padassa. Paista nakkeja (ja mahdollisia sipuleita) hetki, kunnes ne saavat väriä.

 2. Paahda mausteet ja pyre: Siirrä nakkeja hieman sivuun pannulla. Lisää tomaattipyre ja kaikki mausteet (chili, juustokumina, paprika, mustapippuri) suoraan kuumaan öljyyn. Anna niiden poreilla öljyssä noin minuutin ajan. Tämä herättää mausteiden aromit ja vie tomaattipyreestä raakuuden pois.

 3. Tee ruskea kastike (suurustus): Ripottele vehnäjauhot nakkien ja mausteseoksen päälle. Sekoittele huolellisesti niin, että jauhot imevät öljyn itseensä ja paahtuvat hetken (noin minuutin), mutta varo polttamasta niitä.

 4. Lisää vesi: Kaada vesi pannulle pienissä erissä koko ajan voimakkaasti sekoittaen, jotta kastikkeesta tulee tasaista eikä se paakkuunnu.

 5. Hauduta: Anna kastikkeen kiehahtaa ja madalla sitten lämpöä. Anna sen kuplia hiljalleen noin 10 minuuttia, jotta jauhojen maku häviää ja kastike paksunee kauniin kiiltäväksi, tummanpuhuvan punaiseksi "ruskeaksi kastikkeeksi". Mausta lopuksi suolalla.

### Miten tämä tarjoillaan?

Laita lautaselle keitetyt tai muussatut perunat, kauho päälle reilusti tulista nakkikastiketta ja raikasta annos isolla lusikallisella kylmää kurkkusalaattia (etikkainen kurkkusalaatti leikkaa täydellisesti kastikkeen tulisuutta ja rasvaisuutta!).

Ota viereen palasiksi revittyä, lämmintä laffa-leipää, jolla voit pyyhkiä lautasen puhtaaksi kastikkeesta. Tällä setillä lähtee nälkä aivan varmasti! Kestääkö sun keittiössä reilummin chiliä, vai mennäänkö miedommalla poltteella?
